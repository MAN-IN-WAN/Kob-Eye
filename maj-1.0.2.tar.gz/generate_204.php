<?php
header("status: 204");
header("HTTP/1.0 204 No Response");